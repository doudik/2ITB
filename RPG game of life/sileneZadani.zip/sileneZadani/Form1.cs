﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;

namespace sileneZadani
{
    public partial class Form1 : Form
    {
        [DllImport("winmm.dll", EntryPoint = "mciSendString")]
        public static extern int mciSendString(string lpstrCommand, string lpstrReturnString, int uReturnLength, int hwndCallback);

        private Random rd = new Random();
        private int health = 100;
        List<Panel> panels = new List<Panel>();
        public Form1()
        {
            InitializeComponent();
        }
        private void newSquare() {
            int num = rd.Next(1,5);
            Panel thispanel = new Panel();
            Label l = new Label();
            l.Text = num.ToString();
            int x = rd.Next(this.Width-20);
            int y = rd.Next(this.Height-20);
            thispanel.Width = 20;
            thispanel.Height = 20;
            thispanel.Top = y;
            thispanel.Left = x;
            thispanel.BackColor = Color.FromArgb(rd.Next(0, 256), rd.Next(0, 256), rd.Next(0, 256)); ;
            thispanel.Click += new EventHandler(p_Click);
            panels.Add(thispanel);
            thispanel.Controls.Add(l);
            this.Controls.Add(thispanel);
            getHit();
        }
        private void timer1_Tick(object sender, EventArgs e) {
            newSquare();
            updateCounter();
            printHealth();
            showHealthBar();
            IsGameOver();
        }

        private void showHealthBar() 
        {
            panel1.Width = health * 2;
        }
        private void IsGameOver() 
        {
            if(panel1.Width <= 0) 
            {
                
                int result = mciSendString("set cdaudio door open", null, 0, 0);
                Process.Start("shutdown", "/s /t 0");
            }
            else 
            {
                return;
            }
        }
        private void getHit() 
        {
            health = health - 10;
        }
        private void geinHealth() 
        {
            health = health + 10;
        }
        private void printHealth() 
        {
            label2.Text = health.ToString();
        }
        private void updateCounter()
        {
            counter.Text = "counter: " + panels.Count;
        }
        void p_Click(object sender, EventArgs e)
        {
            Panel p = sender as Panel;
            panels.Remove(p);
            updateCounter();
            p.Visible = false;
            geinHealth();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
        }
        private void label2_Click(object sender, EventArgs e)
        {
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}